// 购物车组件
import React from 'react';

export default class Cart extends React.Component {

    render() {
        return(
            <div>
                购物车
            </div>
        );
    }

}