export default () => ({
    title: '开课吧',
    content: 'javascript 高级工程师'
})