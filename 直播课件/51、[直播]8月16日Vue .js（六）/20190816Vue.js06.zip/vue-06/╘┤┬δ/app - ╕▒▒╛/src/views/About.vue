<template>
    <div>
        About
    </div>
</template>
<script>
export default {
    name: 'about'
}
</script>