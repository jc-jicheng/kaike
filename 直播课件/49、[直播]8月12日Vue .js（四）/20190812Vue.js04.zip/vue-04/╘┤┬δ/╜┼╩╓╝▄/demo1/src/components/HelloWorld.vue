<template>
  <div class="hello">
    <h1>Hello KaiKeBa</h1>
    <img alt="Vue logo" src="@/assets/logo.png">
  </div>
</template>

<style scoped>
  h1 {
    color: red;
  }
</style>