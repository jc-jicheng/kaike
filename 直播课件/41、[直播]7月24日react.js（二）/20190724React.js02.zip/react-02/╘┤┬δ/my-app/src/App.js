import React from 'react';
import FriendList from './Components/FriendList';
import FriendList2 from './Components/FriendList2';
import KeyDemo from './Components/KeyDemo';
import FormDemo from './Components/FormDemo';
import UnControlledComponent from './Components/FormDemo/UnControlledComponent';
import DefaultComponent from './Components/DefaultComponent';

function Kaikeba() {
  return (
      <div>
          <h2>开课吧!</h2>
      </div>
  );
}

class Miaov extends React.Component {
  render() {
      return (
          <div>
              <h2>妙味！</h2>
          </div>
      );
  }
}

let datas = {
  family: {
      title: '家人',
      list: [
          {name: '爸爸'},
          {name: '妈妈'}
      ]
  },
  friend: {
      title: '朋友',
      list: [
          {name: '张三'},
          {name: '李四'},
          {name: '王五'}
      ]
  },
  customer: {
      title: '客户',
      list: [
          {name: '阿里'},
          {name: '腾讯'},
          {name: '头条'}
      ]
  }
};

function App() {
  return (
    <div>
      {/*
      <Kaikeba />
      <Miaov />
      */}

      {/*<FriendList datas={datas} />*/}

      {/*<FriendList2 datas={datas} />*/}

      {/*<KeyDemo />*/}

      {/*<FormDemo />*/}

      {/*<UnControlledComponent />*/}

      <DefaultComponent max={-1} />

    </div>
  );
}

export default App;
