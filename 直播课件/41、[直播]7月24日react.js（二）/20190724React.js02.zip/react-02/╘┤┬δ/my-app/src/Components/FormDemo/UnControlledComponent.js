import React from 'react';

export default class UnControlledComponent extends React.Component {
    constructor(props) {
        super(props);
        this.selectURL = this.selectURL.bind(this);
        this.getElementInfo = this.getElementInfo.bind(this);
        this.getElementInfo2 = this.getElementInfo2.bind(this);

        this.refDiv2 = React.createRef();
    }

    selectURL() {
        // console.log(this.refInput);
        this.refInput.select();
    }

    getElementInfo() {
        console.log( this.refDiv.getBoundingClientRect() );
    }

    getElementInfo2() {
        console.log(this.refDiv2);
        console.log( this.refDiv2.current.getBoundingClientRect() );
    }

    render() {
      return (
          <div>
                <input ref={el => this.refInput = el} type="text" value="http://kaikeba.com" />

                <button onClick={this.selectURL}>点击复制</button>
                <hr/>

                <button onClick={this.getElementInfo}>获取元素信息</button>
                <div ref={el => this.refDiv = el} style={{width: '100px', height:'100px',background:'red'}}></div>

                <hr/>
                <div ref={this.refDiv2} style={{width: '100px', height:'100px',background:'red'}}></div>
                <button onClick={this.getElementInfo2}>获取元素信息</button>
          </div>
      )
  }
}