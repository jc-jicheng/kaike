import React from 'react';

export default class FriendGroup extends React.Component {

    constructor(props) {
        super(props);
        // 组件私有数据
        this.state = {
            expanded: false,

            val: 0
        };

        this.expand = this.expand.bind(this);
    }

    expand(e) {
        // console.log(this);
        // console.log(e.target);
        // e.stopPropagation();
        // e.preventDefault();


        // this.state.expanded = !this.state.expanded;
        // console.log(this.state.expanded);
        // console.log(this.input);
        // this.input.value = '开课吧'
            
        // console.log(this.state.expanded);   //false
        this.setState({
            expanded: !this.state.expanded
        });
        // console.log(this.state.expanded);   //false

        // this.setState({
        //     val: this.state.val + 1
        // });
        // this.setState({
        //     val: this.state.val + 1
        // });

        // let v = this.state.val;
        // this.setState({
        //     val: ++v
        // });
        // this.setState({
        //     val: ++v
        // });

        // this.setState((state, props) => {
        //     return {val: state.val + 1}
        // });
        // this.setState((state, props) => {
        //     return {val: state.val + 1}
        // });

        // Object.assign(this.state,{
        //     val: this.state.val + 1
        // }, {
        //     val: this.state.val + 1
        // })
    }

    render() {
        // console.log('render');
        let {data} = this.props;
        let {expanded} = this.state;
        return (
            <div className={[
                "friend-group",
                expanded && "expanded"
            ].join(' ')}>
                {/*<h1>{this.state.val}</h1>*/}
                <dt onClick={this.expand}>{data.title}</dt>
                {
                    data.list.map(list => {
                        return (
                            <dd key={list.name}>{list.name}</dd>
                        )
                    })
                }
                {/*<input type="text" ref={el=>this.input=el} />*/}
            </div>
        );
    }

}