import React from 'react';
import './index.css';

import FriendGroup from './FriendGroup';

export default class FriendList extends React.Component {

    constructor(...props) {
        super(...props);

        
        this.state = {
            // 展开状态的FriendGroup
            expandedIndex: 0
        };

        this.changeExpand = this.changeExpand.bind(this);
    }

    changeExpand(expandedIndex) {
        // console.log('父级', index);
        this.setState({
            expandedIndex
        });
    }

    render() {
        console.log('父组件 - render');
        // console.log(this.props);
        let {datas} = this.props;
        let {expandedIndex} = this.state;

        return (
            <div className="friend-list">
                {
                    Object.keys(datas).map( (k, i) => {
                        return (
                            <FriendGroup 
                                data={datas[k]} 
                                key={k} 
                                index={i}
                                onExpand={this.changeExpand}
                                expandedIndex={expandedIndex} 
                            />
                        )
                    })
                }
            </div>
        )
    }

}
