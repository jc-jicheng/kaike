import React from 'react';

export default class FormDemo extends React.Component {
    
    constructor(...props) {
        super(...props);

        this.state = {
            v1: '',
            v2: 'kaikeba',
            v3: 'css',
            v4: ['html', 'css'],
            v5: '男',
            v6: ['前端', '后端']
        }

        this.changeValue = this.changeValue.bind(this);
        this.changeValue2 = this.changeValue2.bind(this);
        this.changeValue3 = this.changeValue3.bind(this);
        this.changeValue4 = this.changeValue4.bind(this);
        this.changeValue5 = this.changeValue5.bind(this);
        this.changeValue6 = this.changeValue6.bind(this);
    }

    //e = {target: {value: ''}}
    // e.target.value
    changeValue({target: {value: v1}}) {
        this.setState({
            v1: v1.split('-').join('').toUpperCase().split('').join('-')
        })
    }

    changeValue2({target: {value: v2}}) {
        this.setState({
            v2
        })
    }

    changeValue3({target: {value: v3}}) {
        this.setState({
            v3
        })
    }

    changeValue4({target:{options}}) {
        // console.log(options);
        this.setState({
          v4: [...options].filter(o=>o.selected).map(o=>o.value)
        });
    }

    changeValue5({target: {value: v5}}) {
        this.setState({
              v5
        });
    }

    changeValue6({target:{value}}) {
        let {v6} = this.state;
        if (v6.includes(value)) {
              v6 = v6.filter(v=>v!==value);
        } else {
              v6.push(value)
        }
        this.setState({
              v6
        });
    }

    render() {
        return(
            <div>

                <input value={this.state.v1} onChange={this.changeValue}  type="text"  />

                <hr/>

                <textarea value={this.state.v2} onChange={this.changeValue2} cols="30" rows="10"></textarea>
                {/*<textarea onChange={this.changeValue2} cols="30" rows="10">{this.state.v2}</textarea>*/}

                <hr/>

                <select value={this.state.v3} onChange={this.changeValue3}>
                    <option value="html">html</option>
                    <option value="css">css</option>
                    <option value="javascript">javascript</option>
                </select>

                <hr/>
                
                <select value={this.state.v4} onChange={this.changeValue4} multiple>
                    <option value="html">html</option>
                    <option value="css">css</option>
                    <option value="javascript">javascript</option>
                </select>

                <hr/>

                <label>
                    <input name="gender" type="radio" value="男" checked={this.state.v5==='男'} onChange={this.changeValue5} />男
                </label>
                <label>
                    <input name="gender" type="radio" value="女" checked={this.state.v5==='女'} onChange={this.changeValue5} />女
                </label>

                <hr/>

                <label>
                    <input name="interest" type="checkbox" value="前端" checked={this.state.v6.includes('前端')} onChange={this.changeValue6} />前端
                </label>
                <label>
                    <input name="interest" type="checkbox" value="后端" checked={this.state.v6.includes('后端')} onChange={this.changeValue6} />后端
                </label>

            </div>
        );
    }

}