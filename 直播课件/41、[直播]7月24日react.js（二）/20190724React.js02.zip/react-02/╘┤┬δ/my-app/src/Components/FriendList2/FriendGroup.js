import React from 'react';

export default class FriendGroup extends React.Component {

    constructor(props) {
        super(props);

        this.expand = this.expand.bind(this);

        // console.log(this.props);
    }

    expand(e) {
        // this.props.expandedIndex = this.props.index;
        // 调用父级传进来的函数 onExpand
        typeof this.props.onExpand === 'function' && 			this.props.onExpand(this.props.index);
    }

    render() {
        console.log('子组件 - render');
        let {data, index, expandedIndex} = this.props;
        
        return (
            <div className={[
                "friend-group",
                expandedIndex === index ? 'expanded' : ''
            ].join(' ')}>
                <dt onClick={this.expand}>{data.title}</dt>
                {
                    data.list.map(list => {
                        return (
                            <dd key={list.name}>{list.name}</dd>
                        )
                    })
                }
            </div>
        );
    }

}

