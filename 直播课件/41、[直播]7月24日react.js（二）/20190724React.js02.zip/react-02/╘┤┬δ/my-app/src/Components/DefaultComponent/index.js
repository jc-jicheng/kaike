import React from 'react';

import PropTypes from 'prop-types';

export default class DefaultComponent extends React.Component {

    static defaultProps = {
        max: 10
    }

    static propTypes = {
        //max: PropTypes.number

        max: (props, propName, componentName) => {
            // console.log(props, propName, componentName);
            let val = props.max;
            if (val < 0 || val > 100) {
                return new Error('值在0-100之间');
            }
        }
    }

    constructor(props) {
        super(props);

        this.state = {
            v1: 'kaikeba'
        }
    }

    render() {
        return(
            <div>
                <h2>DefaultComponent - {this.props.max}</h2>

                <input type="text" defaultValue={this.state.v1} />
            </div>
        );
    }
}