// i 是 install 的简写  
// 修饰符  -g  全局安装  位置  npm root -g 查找；
// 修饰符 --save(-S) 运行依赖（和运行相关的vue、react）    --save-dev(-D) 开发依赖（和开发相关的babel,less，sass）
// 只是开发需要的依赖就是 开发依赖   ；运行依赖是开发和打包之后都需要的依赖；

// npm i   会查找目录下的package.json文件 将里面的所有记录的依赖全部安装；
// npm uninstall 依赖名称  删除；
// npm update 依赖名称  更新依赖

// npm config list 查看 npm配置
// npm config set  设置下载源 