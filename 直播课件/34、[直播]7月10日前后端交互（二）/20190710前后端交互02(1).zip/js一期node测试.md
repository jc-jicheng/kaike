1. 下面那个模块可以读取文件？
   a http 
   b fs 
   c domain 
   d net

   答案：B

2. 下面那个可以获取当前文件的路径？
   a __dirname 
   b __filename 
   c process.env 
   d process.path
   
   答案:B

9. npm指令如何查看全局模块安装的路径？
    A npm install  
    B npm install -g
    C npm root -g  
    D npm root

    答案：C

4. 从四个选项选出不同的一个？
    A.JQuery
    B.Node.js
    C.Prototype  
    D.CommonJS
    
    答案： D

    来自:搜狐研发工程师模拟笔试题
    
5. 下面哪些是 NodeJS 官方模块？
    A.Querystring
    B.Request
    C.Async
    D.Dns
    
    答案：AD

    来自:阿里巴巴校招面试题
    
6. 下面那个ip代表任意字段？
   a 1.1.1.1 
   b 8.8.8.8 
   c 127.0.0.0.1 
   d 0.0.0.0
   
   答案：D

7. path 模块中可以直接获取文件扩展名的方法是？
   a path.delimiter 
   b path.dirname 
   c path.extname 
   d path.base
   
   答案:C

8. 安装CommonJS规范，在任何模块代码的作用域下内置的变量不包含下列哪一个？
    A.module
    B.context
    C.require
    D.exports
    
    答案： B

9. koa-body中获取req中post数据的方法是？
    A ctx.body
    B ctx.request.body
    C req.body
    D req.request.body

    答案 B

10. 关于koa说法正确的是？
    A.ctx.res是koa中重写的返还对象
    B ctx.response是node中的返还对象  
    C ctx.req是koa中重写的返还对象  
    D ctx.state是对象命名空间，通过中间件传递信息

    答案：D